import { FormatCurrencyPipe } from './format-currency-pipe';

describe('FormatCurrencyPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatCurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});
